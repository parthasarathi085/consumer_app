import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:email_validator/email_validator.dart';
import 'package:chama/Utils/Utils.dart';

class SignUp extends StatefulWidget {


  final VoidCallback onClickedSignIn ;

  const SignUp({
    Key? key,
    required this.onClickedSignIn,
  }) : super(key: key);


  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {

  late String email ;
  late String password ;
  late String passwordConfirm ;

  final formKey = GlobalKey<FormState>() ;

  final emailController = TextEditingController() ;
  final passwordController = TextEditingController() ;
  final passwordConfirmController = TextEditingController() ;

  @override
  void dispose() {

    emailController.dispose() ;
    passwordController.dispose() ;
    passwordConfirmController.dispose() ;

    // TODO: implement dispose
    super.dispose();
  }

  //SignIn_()

  Future SignUp_() async{

    final isValid = formKey.currentState!.validate() ;
    if(!isValid) return ;

    try{
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: emailController.text.trim(),
          password: passwordController.text.trim()
      );
    }
    on FirebaseAuthException catch (e){
      print(e) ;

      Utils.showSnackBar(e.message) ;
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(' ChaMa Sign Up'),
        titleSpacing: 2.0,
        backgroundColor: Colors.black26,
      ),
      body:Padding(
        padding: const EdgeInsets.symmetric(vertical: 20 , horizontal: 30),
        child: Form(
          key: formKey,
            child:Column(
              children: <Widget>[
                const SizedBox(height : 20) ,
                TextFormField(
                  controller: emailController,
                  decoration: const InputDecoration(
                      icon: Icon(Icons.email_sharp , color: Colors.black,),
                      hintText: 'Email',
                      hintStyle: TextStyle(
                        color: Colors.white ,
                        fontWeight: FontWeight.bold ,
                      ),
                  ),
                  onChanged: (val) => email = val,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (email) => email != null && !EmailValidator.validate(email) ? 'Enter a valid email': null ,
                ),
                const SizedBox(height : 20) ,
                TextFormField(
                  controller: passwordController,
                  decoration: const InputDecoration(
                    icon: Icon(Icons.password , color : Colors.black),
                    hintText: 'Password',
                    hintStyle: TextStyle(
                    color: Colors.white ,
                    fontWeight: FontWeight.bold,
                    )
                  ),
                  obscureText: true,
                  onChanged: (val) => password = val ,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (password) => password != null && password.length < 6 ? 'Enter minimum 6 characters' : null ,
                ) ,
                const SizedBox(height : 20) ,
                TextFormField(
                  controller: passwordConfirmController,
                  decoration: const InputDecoration(
                      icon: Icon(Icons.password , color : Colors.black),
                      hintText: 'Confirm Password',
                      hintStyle: TextStyle(
                        color: Colors.white ,
                        fontWeight: FontWeight.bold,
                      )
                  ),
                  obscureText: true,
                  onChanged: (val) => passwordConfirm = val ,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (passwordConfirm) => password != null && passwordConfirm != password ? 'Password Miss Match' : null ,
                ) ,
                const SizedBox(height : 20) ,
                ElevatedButton(
                    onPressed: () {
                      SignUp_() ;
                      print(email) ;
                      print(password) ;
                    } ,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black26 ,
                    ),
                    child : const Text('Sign Up',
                      style: TextStyle(
                        fontWeight: FontWeight.bold ,
                      ),
                    )
                ),
                const SizedBox(height : 10) ,
                /*
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    const Text('Already have an account ?') ,
                    TextButton(
                        onPressed: () {
                          widget.onClickedSignIn ;
                        },
                        child: const Text('Sign In',
                          style: TextStyle(
                            color: Colors.white ,
                            fontStyle: FontStyle.italic ,
                          ),
                        )
                    )
                  ],
                )
                 */
                RichText(
                  text: TextSpan(
                      text : 'Already have an account ?  ',
                      children: [
                        TextSpan(
                            recognizer: TapGestureRecognizer()
                              ..onTap = widget.onClickedSignIn,
                            text : 'Sign In',
                          style: const TextStyle(
                            decoration: TextDecoration.underline,
                            color: Colors.black,
                          ),
                        )
                      ]
                  ),
                )
              ],
            )
        ),
      ),
      backgroundColor: Colors.grey ,
    );
  }

}
