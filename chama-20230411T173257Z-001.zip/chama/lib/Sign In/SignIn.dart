import 'package:chama/ForgotPassword/ForgotPassword.dart';
import 'package:chama/Utils/Utils.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:email_validator/email_validator.dart';

class SignIn extends StatefulWidget {

  final VoidCallback onClickedSignUp ;

  const SignIn({
    Key? key,
    required this.onClickedSignUp,
  }) : super(key: key);

  @override
  State<SignIn> createState() => _SignInState();
}

class _SignInState extends State<SignIn> {

  late String email ;
  late String password ;

  final emailController = TextEditingController() ;
  final passwordController = TextEditingController() ;

  @override
  void dispose() {

    emailController.dispose() ;
    passwordController.dispose() ;

    // TODO: implement dispose
    super.dispose();
  }

  //SignIn_()

  Future SignIn_() async{

    try{
      await FirebaseAuth.instance.signInWithEmailAndPassword(
          email : emailController.text.trim() ,
          password : passwordController.text.trim()
      );
    }
    on FirebaseAuthException catch (e){
      print(e) ;

      Utils.showSnackBar(e.message) ;
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text(' ChaMa Sign In'),
          titleSpacing: 2.0,
          backgroundColor: Colors.black26,
        ),
        body:Center(
          child: Container(
            width: 400,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 20 , horizontal: 30),
              child: Form(
                  child:Column(
                    children: <Widget>[
                      const SizedBox(height : 20) ,
                      TextFormField(
                        controller: emailController,
                        decoration: const InputDecoration(
                          icon: Icon(Icons.email_sharp , color: Colors.black,),
                            hintText: 'Email',
                          hintStyle: TextStyle(
                            color: Colors.white ,
                            fontWeight: FontWeight.bold ,
                          )
                        ),
                        onChanged: (val) => email = val ,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: (email) => email != null && !EmailValidator.validate(email) ? 'Enter a valid email': null ,
                      ),
                      const SizedBox(height : 20) ,
                      TextFormField(
                        controller: passwordController,
                        decoration: const InputDecoration(
                          icon: Icon(Icons.password , color : Colors.black),
                            hintText: 'Password',
                          hintStyle: TextStyle(
                            color: Colors.white ,
                            fontWeight: FontWeight.bold,
                          )
                        ),
                        obscureText: true,
                        onChanged: (val) => password = val ,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: (password) => password != null && password.length < 6 ? 'Enter minimum 6 characters' : null ,
                      ) ,
                      const SizedBox(height : 20) ,
                      ElevatedButton(
                          onPressed: () {
                            SignIn_() ;
                            print(email) ;
                            print(password) ;
                          } ,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.black26 ,
                        ),
                          child : const Text('Sign In',
                            style: TextStyle(
                              fontWeight: FontWeight.bold ,
                            ),
                          )
                      ),
                      const SizedBox(height : 10) ,
                      GestureDetector(
                        child: const Text('Forgot Password?'),
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const ForgotPasswordPage() ,
                        )),
                      ),
                      const SizedBox(height : 10) ,
                      /*
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          const Text('Don\'t have an account ?') ,
                          TextButton(
                              onPressed: () {
                                widget.onClickedSignUp ;
                              },
                              child: const Text('Sign Up',
                                style: TextStyle(
                                  color: Colors.white ,
                                  fontStyle: FontStyle.italic ,
                                ),
                              )
                          )
                        ],
                      )
                       */
                      RichText(
                          text: TextSpan(
                            text : 'Don\'t have an account ?  ',
                            children: [
                              TextSpan(
                                recognizer: TapGestureRecognizer()
                                    ..onTap = widget.onClickedSignUp,
                                text : 'Sign Up',
                                  style: const TextStyle(
                                    decoration: TextDecoration.underline,
                                    color: Colors.black,
                                  )
                              )
                            ]
                          ),
                      )
                    ],
                  )
              ),
            ),
          ),
        ),
      backgroundColor: Colors.grey ,
    );
  }

}
