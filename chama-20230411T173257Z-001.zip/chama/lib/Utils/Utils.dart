import 'package:flutter/material.dart';
import 'package:chama/main.dart';
import 'package:flutter/material.dart';

class Utils{

  static GlobalKey<ScaffoldMessengerState> messegerKey = GlobalKey<ScaffoldMessengerState>() ;

  static showSnackBar(String? text){
    if(text == null) return ;

    final snackBar = SnackBar(content: Text(text) , backgroundColor: Colors.red);

    messegerKey.currentState!
    ..removeCurrentSnackBar()
    ..showSnackBar(snackBar) ;
  }
}