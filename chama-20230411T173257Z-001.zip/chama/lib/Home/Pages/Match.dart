import 'package:flutter/material.dart';

class Match extends StatefulWidget {
  const Match({Key? key}) : super(key: key);

  @override
  State<Match> createState() => _MatchState();
}

class _MatchState extends State<Match> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Match Stick Home',
          style: TextStyle(
            fontWeight: FontWeight.bold ,
          ),
        ),
        backgroundColor: Colors.black26,
      ),
      body: Container(

      ),
    );
  }
}
