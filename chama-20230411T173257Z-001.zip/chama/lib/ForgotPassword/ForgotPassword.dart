import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:email_validator/email_validator.dart';
import 'package:chama/Utils/Utils.dart';

class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({Key? key}) : super(key: key);

  @override
  State<ForgotPasswordPage> createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {

  late String email ;
  late String password ;

  final emailController = TextEditingController() ;
  final passwordController = TextEditingController() ;

  @override
  void dispose() {

    emailController.dispose() ;
    passwordController.dispose() ;

    // TODO: implement dispose
    super.dispose();
  }


  Future verifyEmail() async{
    try{
      await FirebaseAuth.instance
          .sendPasswordResetEmail(email: emailController.text.trim()) ;
      Utils.showSnackBar('Password Reset Email Sent') ;
      // ignore: use_build_context_synchronously
      Navigator.pop(context) ;
    }
    on FirebaseAuthException catch(e){
      print(e) ;
      Utils.showSnackBar(e.message) ;
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Forgot Password'),
        backgroundColor: Colors.black26,
      ),
      body: Center(
        child: SizedBox(
          width: 400,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 20,horizontal: 50),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const Text("Receive an email to reset your password",
                  style: TextStyle(
                    color: Colors.black54 ,
                    fontSize: 20,
                    fontWeight: FontWeight.bold ,
                  ),
                  textAlign: TextAlign.center,
                ) ,
                const SizedBox(height: 20,),
                TextFormField(
                  decoration: const InputDecoration(
                    icon: Icon(Icons.email_sharp , color: Colors.black,),
                    hintText: 'Email',
                    hintStyle: TextStyle(
                      color: Colors.white ,
                      fontWeight: FontWeight.bold ,
                    ),
                  ),
                  controller: emailController,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (email) => email != null && !EmailValidator.validate(email)
                      ? 'Enter a valid email'
                      : null ,
                ),
            const SizedBox(height : 20) ,
            ElevatedButton(
                onPressed: () {
                  verifyEmail() ;
                } ,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black26 ,
              ),
              child : const Text('Reset Password',
                style: TextStyle(
                  fontWeight: FontWeight.bold ,
                ),
              ),
            ),
                const SizedBox(height: 10,) ,
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black38 ,
                  ),
                  onPressed: (){
                    Navigator.pop(context) ;
                  },
                  icon: const Icon(Icons.cancel , color: Colors.white,),
                  label: const Text('Cancel',
                    style: TextStyle(
                      color: Colors.white ,
                    ),
                  ) ,
                ),
              ],
            ),
          ),
        ),
      ),
      backgroundColor: Colors.grey,
    );
  }
}
