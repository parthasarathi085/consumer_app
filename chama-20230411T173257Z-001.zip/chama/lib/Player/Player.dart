import 'package:flutter/material.dart' ;
import 'package:audioplayers/audioplayers.dart';
import 'package:chama/main.dart' ;
import 'package:file_picker/file_picker.dart' ;

class Player extends StatefulWidget {
  const Player({Key? key}) : super(key: key);

  @override
  State<Player> createState() => _PlayerState();
}

class _PlayerState extends State<Player> {

  final audioPlayer = AudioPlayer() ;
  bool isPlaying = false ;
  Duration duration = Duration.zero ;
  Duration position = Duration.zero ;

  
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    setAudio() ;

    audioPlayer.onPlayerStateChanged.listen((state){
      setState(() {
        isPlaying = state == PlayerState.playing;
      });
    }) ;

    audioPlayer.onDurationChanged.listen((newDuration){
      setState(() {
        duration = newDuration ;
      });
    }) ;
  }


  Future setAudio() async {
    audioPlayer.setReleaseMode(ReleaseMode.loop) ;


	/*
    String url = "https://youtu.be/8-PRmp2h9ck" ;
    audioPlayer.setSourceUrl(url) ;
	*/

    ///Pick from a folder
    /*
    final result = await FilePicker.platform.pickFiles() ;
    if(result != null){
      final file = File(result.files.single.path!) ;
      audioPlayer.setSourceUrl(file.path , isLocal : true) ;
    }
    */

    // Assets
    
    final player = AudioCache(prefix: 'assets/') ;
    final url = await player.load('audio.mp3') ;
    audioPlayer.setSourceUrl(url.path , isLocal : true) ;
    
  }

  
  @override
  void dispose() {
    // TODO: implement dispose
    audioPlayer.dispose() ;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.network(
                  'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWFhUXGBoXGBgYGBcWFxgYFxgXFxcYFxoYHSggHRolHRoXITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGi0lICUtLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAABgUHAgMEAQj/xABLEAACAQIEAwUDBwYLCAMBAAABAgMAEQQFEiEGMUETIlFhcQcygRQjUpGhscFCYnKCstEVJGNzkqKzwtLh8AgWJTM0U4OjQ+LxNf/EABoBAAIDAQEAAAAAAAAAAAAAAAAEAQIDBQb/xAAyEQACAgECAwYGAQQDAQAAAAAAAQIRAxIhBDFBEyJRYXHwBTKBkbHBoSNC4fEzYrJS/9oADAMBAAIRAxEAPwC8aKKxdgBc0AZVqadBzZR8RS3n3EIQGxAA5n8PXy3pCz3iwOQysdwAfJhsbeosfiarqRbSXAMUn01/pCsPl0X/AHE/pL++qSPEbbkMQCPHl/leuLHcTPHGuo7t3gL9AAAT63o1BpPoBHBFwQR4jcVnVIcL8eyIQC1x1BNx99W7kubJiE1Lz6jw/wAqlOyGiSoooqSAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKXeJ82EScySdlVfeY+A/fUxjJ9Ck8/IcyfCq+4uzQQanNjOVNidxED3QbdTqsAB7xNuQNsskq2Rrjhe4o8SYwJdsS1pCp0QL05+8RyHnzJpImzNmPQDwAsBXuYa3a7amkc8r6mb1Pj9gHjzr3EZcsQ751SfQF7L13tv9o9OtQtiz35GLTG17n8K1ZrJdYyDfu29CD+61e4hwq72ueSje311qmQmG9tg1wfIi34VLKI5IZiDsbVYHA/FkkDrqO3j+/yqugbV14PEEHnfyqQPrLLccs0YdTz5+VdlU17NOKdBCM11O3p5VcSOCLg7Grp2Uaozory9AqSD2iiigAooooAKKKic74gw2ECHESiMOdK7MbkC52UE2Hjy3FAHZj8dHBG0szrGi7lmNgKrnNPbZgY2KxRTzWNtQCop9NZDfZSz7U86OMdUjPzQ3XVdQFH5ZB31Mb2v0HTeqnlSxIBv51XVZZqj6N4O9quFx84w/ZvBIwunaFdLkc1BB9629utjVg18WqxBBBIINwQbEEbggjkav/2Se0c4y2ExbD5SB82//eUDcHp2gAJPiN+hqxUtOiiigAooooAKKKKACiiigCNx8wUaif0fgCT8LA7+ANVTxNhX3d11M7AILAszEGxA5Gy7AHYXJPIXs/MBdhffoAeVhuxPkNvWwHWl6TLVeR3axVfeY2Go73iB6LsNbcyL8gBSeV94dwpaRDiyVcGGmmYGZr2b3hEhJ0t5s1jb4nfkUHMM0MjNbYXNhzNvFj1PWp32hZ40spjB7oOtumuQixYjoALKB0A9KUUO9aY4/wBz9+/Azyy/tXv34m50stzuT1NdkD/xZ79WA+w1qYBh1uOVuX+VeadMLeZG3p1vV5GcTgYUKbV4DRapAmMkxpRgQfWr14Nz8TRdmx7wtbzFfO0TWNxTnwxnJUhlNmXp4jrUXRFWXzicbHH2aSNpMz9mgsd2IJt5cufmKiZZzh5A6E6fyl6MPTx8DUHjcfJLGHWaVUd1tpkdSmjC4kkXB5akRyOR61KY5y8cTsLM8SMw/OZAW+0mp4jFpxxmnv7/ANDWBJbPkxzjcEAjcEXHoa2VE8N44S4dDfvKNDDqCu2/qLH41LVdO1YnKOmTj4BRRRUlQqk/bdjrzhLgdmg0gncse8WHwKj9Wrsqq/bJw0MTJg2B0s8nYsQN7WZ/uV/qqs9lZaCt0ijcRmTuLE9AOu9q1RtcW2pgzXhR0sIkdm79194hY9mPLxB2paU2qsZKStFskJQlUjB1tW7A4p4ZEljbTJGwdT4MpuK8N2PnW/H4LswD1PSrX0KKLas+ruEs8XG4OHEqLdoveXnpcEq6/BgRUzVPf7PGa6oMThSf+W6yr+jILMB+sl/1quGrEBRRRQAUUUUAFFFFAETi4bkkbMe6DzIW/IeFz9tvClL2i8QDDQGJdN2Vzbq6ot5B4C/unraQW3NN+NPZoz33UHfwve5t5bn4V88e0/NjiMc0YHdgHYqAdXfB+c36nV3f/GKxa3GE9rFrEO8haZySzsbnxY94/VcbdLissuwTStpHLrWGJRhoj8Bflb3zffzI0/UB0pz4Qy+wBI86rknpjZfFi7SdHuC4XJUb29B9/U12HhBVQrcm5vTpgoBYV3S4fak+0m97H3ixR2opfN+GXjJKC4+6oAggkGr4x2XAjlVW8Y5P2balHrW+LM29MhbNgSjqjyFgDwrswOI0kEVw10YeQUyKFq8DYyOS0UyK6E3CtuoaxG3lYn4G1PebzA9Ryqk+HsdoYb9dqsxMMmITtNcikjcKwAuNuRU71STbjpbNIN6rMeF5iuPFnIBja4BsDYra45Hmacc6zFkQlZLH4UhcN5CjYyxklHzbG4Zb81/Nphz7h5Ah+dm+LL/gqq2x8zSe+ZWjDhbPJ5EmMkxbS1lvpFth4CuT/eLE9qw7c6Qt7WT91RvCmRo0Up7SUWY8mXy/NrRh8jQyP85Lsv0l/wANYyk9u8xqMFcu6v4O6HijF2BM5N28F5fVWvinO5ZfkojfW5xMehTa1zqUk23tpZr+tQy5Mule/JzPUef5tTXCGQqMQspLMIgWGog2ZhpFrDwJPwoUn1YZMaUW9KHbAZTHCpOxY6t/0jqP4VVXGGBwqSu0mGVr3uyCzDzsvPrVp4/EbGkjMIlklUWvc/651nKcU0o9CMEHLU5dfIQctyhIohK4GhjdGfZ1HVWHpvfnvS5xFjVkfuG607e1KVYhCiDSVJYj4C23xquJufMX2Jt4kXt8OVNYbl32K8TJRXZx5E1whneIwju+HlMZZQrEBTcA3A7wNMLe0LM7/wDWv/Qi/wAFIAcjkTUplcBmXZXLKd9O977jbnfZvqrWVrezDHJPu1uNqe0HMyCflj7H6MP+CtuI49zIWYY17eGiL/BSzFhN2Xvcr2/0K04vBkRXJa/gf/ys735jGlaXt7R9Dezji1sdE6y27aLTqKiwdWvpa3Q90gjyvtewc6+YeG+KJ8sUyYcRs0iqGEoZhZdRFtLL9I1ZnAPtNlxLImLSNe0bQrxhlAY7KGVmbmdr35kbda0jJVuYTxNzeldLLSooorQwErirPOxQkd4prkI8SrMUBPhtY/pCqZwOWK2KxDSkacOg7ViT3pWt2p82J7c+W3UCrK48xfYjFSsoAUxiO+4eUsrcuVlOgkHY6VFudU1/CLfJXTrNIATvduzAeQt4ks0Zv+l41nu7s32WmvA6ssDYjUSo1NL2jNbfkQqA/RGpvs8KsDJMJoUCq9yGTERd6NNS+HjTllXFsTHRKpiYeO3+dK54zk9uQ5w0oQ+bmx4wybCu89KjMuxqsAQQRUp2guKwiMT5nkyUmcVYEOrbU8mZSKgM6RADdlHqRRPbdBj3tMovFxaXI8K5ztUxxVGFxBHkKhnNPxdqzmTWmTRJ5fiuQPwPh61YfCea2JRjzH2+NVRG9jTLkeNOwvuNx+6okiYumW/wsf47/wCM/etMfEI7hpO4JxurEav5Ox8txTdnzXjPpUf2M0b/AKqIDhBfmZv0zWjBj5yT9GurhNfmJLcy5rRjposCHlxjhAQdKKQZJCANlUevPpS+luqGnkjFytnJlOCMrxp0uxPoP37D4118ARumFmMrEzNiJtYJvo7NzGqKOi2W+30qgeC+MFkxYUKY45VKRISGYvqDLre2xIuNtrgc+rZmEaxGWUWVubge45C+8b8msOe3x51pLFJQ25i8s6yZPL9nk+L1Ai+4pHzrHvEWYNqPhYXWw6eO/jXXxDmUid6NH7Rfybb9OfTTuBe9t6Rc/wA4aaISgAE3DaWDBT8KXxY5N20Nyywxp7+Zoz+aTFL8omkVQAVQWOp2UDu2HIi678t70uNHarP4CjSbCIHRb63AsCWdjpBNhzOmNNvzSawz3gNHZmjcxtudJXb08RTEc8YNxeyToTnw8siU1u2rKvemDhqZoHbtBJGkylVcalCupuDfnYd4HmbNXPkmVK+K7OUhUQ6pL390Mq22B5lhz2pgfGNHJiIyF7GUyiOJVIU6WAawfde8Aee9/C9XzTtaEr99PPrvtRlgxu9V1v7v8HmdPHh37TtGlD7FhEQF2YbMe6R5DfauPNNPY7X9Sb3rv9oA/ieEYsQXZjoG6bKBqv4jl+vUKZteFU9eR9RtWeLeCl519tvBDLlTnDyv78+rMM0HzSelTPCqHRBbmZUt69oLVEZ0Pm0HkKZ+CoL/ACUeMsf7YNXfyr1Jiv6kn/1/R9D9v5UUaK9ps5ZRftuxrri+y1d0ojgW+l2qMfDkPuqs8RNcRqOSLb4sxdj9bafRRVk/7QEVsbA30oSP6L//AGpHyDLe1J+qsput2b44uWyNeGzqWMfNkC3iL0yYaSbFQdtLCjxqQpdbAqTsNW91v0PLzFckPCkiSd4Eoeo3+BFO+V4ERwNClxG/vqAAGJAFztS08mP/AEOY8Wbq9vBkRkswgYAMSrC636eXwp5gc6NRpCxWWhHQBmO5tfnYkbfCrEWK+GUeP20vLd2mNLaKTVbiPxBjCD85iuxU9BzPnasctweBlXeYzsfpNY/AC1ReccOyvMJVI1qb2bvDY3Gx2sPCt+d5A0jwNBAICnvuCBq6+4u3Pl5VpHSo/P7/AD/JnPVr3x7ff/Ao8WYURTlFJK2Gm+9hv3b+AqFNM3HUGmZPNPuNLJprE7gmI546ckkvEK6cFiCpFc1CnersyRZ/BOYWm1X/ACQD8TVkZnjEEDPI4WMDdj9Vh4nyqgcmx7RkFSAel+XoacsvzHEYtosNqW4uwDCwZgCe9sbixI26HzrOuhrqd2MjcYRYXBTYiEC2vs4Edu/JJ3dbG17WDBreTeVU1jcfJM5kldndveY8z5eQ8qauIYCuBiRwAy43Eo4UgqraY7KCOfum3kN96SyN7VpFKtjHJJt7s6kxJW1jYjkRsQRyIPjTzwpxw8kkWGnXUG1IZAwDOzvrvJq7tralNujC3Kq/FdvDhtjMPb/up+0Ks1ZROmWdmmCkK9yLXYAsDbc6UutnJJY933mbY2HnWufZyJSQE0kG3QAAHdQB5j0uL1bM7ns4zHJ2qtEpupuXcAFNRLtsx1Xb8m3hutLZ0lsROPCaQf12qsUrLzk6Hv2bYN8Rh2VbqYZlKsCRqVyGkS45Gy2v+cKsDE4fsIwrEs3Uk3O/T4Uu+yzHxJhYooiGlZneUbbEtp3F77II6ZszQsxJrmZ5d9rzOpwyemN+An4bKIzLLJ3Vfs2IJ2tazXJHIbbnoLmlbiDEBsVhwptZrsb3sHa78/zasjL8D2rSIrAP3WANu8AJLhhY3SxII63qu+J8qDYqZEOtQzAP71yY9V9jyve3QbdNqvglcnb6f4Didk1FdV+bPMdi8JLhJYWf56EsYSzXvuCyqeRUgEW8h1qFwcRXDXPJpLj07o/CuWaBpcQ910ksS1hsCdyfifvplzHBgQoi9NIt9VNKKxpK+bv026CsLyapVyVeu5H8R+6voKdfZ/DeTBj84H6gTSZxQhAXbwqwPZrHebCeQJ/9bVHSPqb8pZX/ANS7bUV7RTZyij/9oWL5/BnxSUfUYv30q8KDTanr2/w3+SN+dIv1hT+FIeRtYil8/JjnC/MmWXgCCK7J4wFvURls3Ks88zMJGfSudFnVktyBx0muQHwNWHAfmkqs8GpLoSfe39KsnCqewXyq65/Qzycl6/o48XgkY7jfx5GtBwZA3vat2IxF2t1FdjsClRSZNySRTvtMS0kXo33rSWacfaZJfEKv0U+1if3Ck409g/40c7iv+aXvogooorYXN+HN9vq9amsqzKxUMWBGwZDZ1vt3T19DS6DW9JNwRVWiyY/DhmWTL8SA6skb/K0cElnKxSCSN15rIB0PXxFV5Ib2NMMWayQhmjaxtp3F7AoRtf1P1ml8KNIqYcjPJVmIau/h17YzDfz8Q+t1FR9q7ciNsVhj/Lxf2i1YoW7lksiR4cMIw0iqSF0hVOgnSoViPdVvG5vb82n+ID/G8T/Py/2jVa+Tuq4aNQJNK2CiUmxZVbqdggYHS3IbW/JqreK0tjcSP5Vj577/AI1ES8+SNfD+N7GdGJbSTpcLsWXot+dr6eVXjnkow8Sg21BQNIPLblXz9UrmGfYrE2R5C17LYbavWsc+DtGv5GOG4hYotPfwRYuSYkydpIH/ACtJs23utfl4A1H5zhLLIwJL9oGJ8Tzv8a4+FUkwziNj805IC3BtI6tY7HY6FBIF/eX4ss2DZtaNcGSQqDa9tP5Y6ld7bbcvEUhKoZPI6UZa4d5UxTxEYLhlAubBhcD0Nz4fjWSEPIpHLzuCCOhB61LLhRaBmA1MO9uCpAJAZbGzJYE3vblXPlGDPvaVDdo1wANO5NlGnbSLWrdZFRmk79SIz1u1JXwqxfZnCBPAvVY2PwsB+NZQ8OQvZ2jXUqjpsTbdiOR38RUnwRlxixp32MbGxt9JLEeA97ajFljOcYopmVRnLq1RZVFFFdE5RVft5X5rCH+WK/XG5/Cq5wEdqsj2/r/E8O30cQD/AFJB+NV7ljAgGls+w7we4x4WfSl6i8xmMitvzqTxWG1wHSbG3MUkYDFzJIYpD42J5E9BfzpPDDVbXM6GbJppPkyYy/FuHXY7f65VZeWZkWj0gc/spOyqGVDqMOoA2Onn05fXTLJiWgRmMLKo3Ja/lsABcncCw8aJ3q2RKS0btP39zRn0pjdX6HY10xY268+dQWLxeInRi6qiE6FXm24NyTyuCRy8DXVj5Fw0DOeUaX9SBsPUmw+NYvyNttPe6FV8VYvtcXM19g5Ufqd37wT8aiDXuokkncnc+p3Ne11kqVI4Mnqbb67mNFeGvasVCvK9rGgDveT5s/D7q5elZq3dYeQ+8VjfaoRWfM1munKv+og/no/7Ra5ya2Za3z0X87H+2tXKFtYUyGOPtFCMhDowsw06ZApKqq7aXNxq253vbVV/FkOjGTJ9EqPHkiVZGBij0R9mzbSOWcWLBtTdoFW7EkWA0kWtdrd3at+LHJxkxbZiVJ9TGl6pHmaT5GfCvDcuOmMUZChVLO5BIUdOXU9BtyPhTjlns1j1/OytIAQCoXsxe9jqNyfQC3rTF7F8AqYIzWu0srA/opZQP2j8afpoUNnHvXF/zt7fhSWfiJ6pKLqhnDihScldinhckRpxGlgcOwXTa41tGCr7tfuqefiwFd8eXM7DmmtXIsF2cOJHTcbqxUG/W3kK5cvimjWWaUGOWaYybjdQZBpUdLhAq3rix2Nk7x12IZSgDLcBwY2Iupv+USL2upGwG6UqUq9++Y7Umvfvw+xqzfCqkUTSAuGeMBO6h1I/ZlCoHeGnVYXGwYmujJsIx3kUKzsWYDkGZtVh5A7VsyzDGZ1ufdYyNyI2LhRtsN77DchVJ33M1JCFudj0/Dai6Ra6dGvEzW1LaxLRqOlw0gBI8fCpHhpB8rZvGPbyW40/WN6WcbjWeKVSbtCokQ9brZr/AH/bTdwsFL6hvdAb+R5fDateGX9WP1/BhxG2KXvqhpooorsnKK09vQ/4cp8Jk/vCqg4YxVwUPNdx6Vcvt2S+Vk+EsZ/rAfjXz5gsSY3Djp08R1FZZY6lQxw+TRJMtnL5+4RUBmWF72oC/keorpyrGhlDKbqwqVgwqyC1cxNwZ2n3qMskxdl7rkb3IPj8alcViDKAGkZzfZelzXJhMkHlU3g8rCb1FtmjlCO65/Q55cOAqr4b/GkH2m5xfThlPg8n9xT+18Fp54pzRMNC0rb2FlH0mPugep+y5qi8ViGkdpHN2Y6mPmfw6elb8PjuWrw/IhxWaoaer/F/s1is6wr0GnjnHhryvWrwUEHtY16a8qQMwdjXq1jWxaCsjG1e4P8A5sZ/lE/bFZNWEXvLbnqH3ipRQuDK1ZQC0IXU7qAoYE6XIR7kAa2sTbe4AN7LVZcckHHzkciUI6c4kNWVgiuhlMokHayAFSysjtMzdkTe4ZTaxFjuByIvW3HMdsdNbl83a2wt2SVWPM1yfKXb7J4rZVBtzDnwveRzTPhU1KPJr/UTalT2bYq+WQItu6lifM3Y7dLX+ymTIZye1U81IP1g/urmz3yff82NqLUL9P0duLNrErcD8fwpWxvD8eIcksyIR2QCHSNN7kWtbx+vpTPmcwCkEjfbw+qoi92UaiQLkADYcrc/Ws80qmXw3pOqDLlQBV6W8CWZbWLeJ2F658yhJ5XB8vPnWybFud1IUHkTz/fULi8zCg7gn6TGwHw8qyk09kjSEZN2xez/ABDRTAhWIA0tYE3Vgwb7yaZvZDKWh73vCOMG/O9jtS/Pl4n787MIzyXdSevqBTd7PI0DT9ncL3LLtZefugCnOFrUl1K8TaxS+n5HiiiiumcoQfbct8qk8niP/sWvm819Le2b/wDlTfpR/wBotfNRqkjSPImMixrRnbdTzH4infLcwGxB2qvssbvW8abcJhuo2pPiIp7nW4OTca5j3gsePGpJcyXTzpKwmHY7Em3xqRjhCjr9d6S16R6WGMtxX9puJaQJ4Bth8CL+tINWLxThtaEVXkiEGxrocNK8ZyOOhWUxr29eUUwJ2BoFeUVIGRoooNQB4K2oKxPL40LUlZGbDatcfvLt+UPvFZ1pdrb+G9SUZb2EmDRtpj1NHNMGj7WTvDtu/pVl0AsA5BvYd5bi7Wrzjk/x2Tfon2KBt5VZWHmkUanK96aRI+8oAXt2Cq+55g31cwQAQTYGsONmHyyQjlZQL+CrpH2Cqx5ms13SzvYvOWwbqd9ErKPQqrf3jT/gcIyFzfdrbdBY/fuaXPZHkLYbAK7+9O3bEfRVlUIPXSAT5tbpTHj3LggMEQbFup35AmudmrU5LxdDeOTcVHyV/Q1zzpfSBrbmbbADxJJtUO+OsxAAYg2sAbDyJO53ufjXQsOq4QFYxuT9Jibc+p5+nlXDi5bdyFGMmwFxsB9I/Dr5jY0m7fIaikjnxWOOtVZjqY2UKCb9PT7LbUTvh8Ox1MGcnSt9zq06mvt0uB4XrbFho4AFB1SN3S3M787dbdTvUFmeEaeHXCXTctqlN2YEhCwH5JKgciRtfkLVpGCT392Xd0YYzMi/Xa9Pfs0icJKXBBJFr7bW52pKyXLSp7gLsT3nexZdvqW5O1viasLgiIr2+rmXF99VjpHUU5wzXa0vBmHGTvFVdUNVFFFdE5Is+0LKjisDJAHCFyg1EEgWdTyG55VVDeyuK1hiZS235CW89r3H1mrm4ol0wFvBl/aFIH8InXe5tek+JyyjJJHQ4PApxbaE3M/Z0YYTJHKWZBfSQBqtzC26+W9HDsodRTzh5UmYhlB8L37p8R51GZtkPYv20a82JcDlY3Oq3Tfnbxv40tKbnBpj+KCxz2MUjtXrVsXcUNHalByyGzRLgmkHPMDo73jVhZo6qCWsqjmTt9f+v8q7z3Mu3cKgJW+3ix9PCnuFs5vGuLV/Yi4Y738hWLrambB5ZoSx947n93wqMzHBW3ptTTexjl4LJigpSW5GVjXpFe1oJUeUGi9e0EHhrOM1hWaCoIZuY7Cuacd0+hrqKi1aJVup9D91SUZcGBjiVZ10yOrTyCQSC6FzJ3wikEFLAb3HeH6Vq247jtjHFrdyPb9QcvEXvv1q0stiMkZHZKpMrOkllIkVpVfUwuG5gKR17vW1V17SIz8ve+50Jy5bgnb66iPM0n8peXC8xGXYOx1McPFY879xd/OvcXA7kKxuoN2/O8B5CoH2fZj/AMPwyawxSLe35I1MFU/nAWH6pqRxWbWBNxYeHWublUb3H8UJdAzvMzGCABe1l2uEPiBtc1CT52sbNEpu9gxc37wa+k+hAuB4EVplxZZ+1MmjQ6G9tRuWAXbr6dbedQXFVop4lRiB2YZ1sd3LtExNz3baFFqpGNv7jDUcdIm8Lj9N3trkIIINtAU9ADzJ8T57V6c1vs6Nsbi5ABPXUwv+HKoWOSs2l86jQmbuCbsme2cKAqkXvtddPX66cPZuzGKYtz7T4+6vPYb1WkeOK7A7dR/rlVn+zmUPA7D/ALn91aY4WLWT6CXGqsX1Q3UUUV0jkkHxl/0knqv7Qqrw331aHGf/AEcvoP2hVWRHlXP4z5l6HV4B9x+v6RJZKveHremXMJNKhvH8Tb8aX8sFnAruzPNJ2x/yGJICLLbtIwf/AIlc3PPxrCC29XX1H4YJZp0q7sXJ26VKr/Ihf7+RRl1EbSWdgCUUCwYgWKSKbW8b1GT+0OTvBIIluQVN3LLYEWuzE2N72FtxzpryWGOcSH5LlkQitqaTDxhe82kclN9/HxFSmW5fg2xRMcMB7LDF2EaBYGnBAJsAAVswHhcVvF4qtL7mebguKg2ssoqukblvtzulvarfryKnmXFYs3kJ09LjSo/RUc/X7alcvytItxu3Vz+HgKtnsV7IyjC4QKDb/lKW5gE2Nza7D663YTDwMoaWDCqWuYlWNQzGO5YlRzQBWvfb7KyhxUcsljhatWtqVePoa4+x4e8ji5SXW03fWl0pW/JdSq2A8K5sRh9Qpqwmc4xoZJY2hRItGsLBApJlJVSB2Zvy33qTyjG4lhDNNicMsDOdSvHEHdI2AlVVWHfY22PUV2J/Cp4ouU8kVXrzq/ATfx2Gbuxwyd+f6oqT+DiSzDlcgfCuPE4fSasLESYbDYdsZNGWjaQph8PfQZG9462G4jRStyOZNr1y5/iMZhYknxGX5YYmKq8SwoZIi660WVge0RmW5B1Hz8KVhclYpxXZ43pW76+T5lfkVM8G5UmJxcccpIjAeWS2zGOJGkZQehNtN+l6Y83xsEcUOJGU4c5bPpVXu/ynWEHbL2vaatSyCUAlbEJ8anMuwYyzDnEYcJIz4i8GIeNWkOGkw8boASLoe86ta1yG8qvLuq2ZYMcs+SOKHNv08+ZwwQQY4thvkeHhYo/yd4o+zZJAhZFdlPzqm1jqubm+1IOHjuAfEXq4c64szKBITJ2OmdQVGhG7rBTZh02YbedQufYGEYrL4Gjwom7YLiEw8aINEj4fskkCKAW0l9vBvMVSDvYf+I4IxUcsIxjF7JKV21za2XLk/uJeQ5ScTPHAGC6idTHkiKpeRz6KrHzsB1prw8UPZythsshlw8XvyT65JSDsGZg40k89KCy/bXRJjp2bGJDHho1jSYOUghjfsdXZsqsqXvZgOdZcLpifkWKKNGMPom7RWt2hb5ObFO7e263sR1rOWRykoxvr08NvscRyvkMGRmF8L28EbL84qSRl5JBGV0e4Sb9noJa3M3a561XXtFi/jrm4tojsdrEadiLbbixqw/ZdpGFxDsbKkiuxteypEzXX86ujATPi5TJFHh8OGYRCV4kkmc21BLspLG1mIFgBveojlWmPVtckP8Nw08+JzbSjHnJul6bW234JEL7M8asuD+T9lpSJ/nHU7ySSNdLWNyQLar7WC/DvmgZgGQo6tyPaJHz5C0pUqbEbEda0Pn+KQyGJ42RG09ssES9SBay2AbSdjeuzN8fjIYoJjPHIswJW0Md12BN7x897fCk55ISblvXP9eO/0O9j+GZ8WmDlC3st5bur/wDnZ1vvRB4SyxykESySXKsnehCROikBzsSGLm/K42O2+3DxHRLjcSizPGiRRRMLx6pH1LrW5uFA1W8gKb5maLCSmUxSTJE0y/NJpUFEspGkK27X5dK4cizmRsDPigESZUmXVGipfsxCYyye6WGthe3Kn+G4ZtrM6a1JNdd6VbWkuV+S+3NnJ01z36N0+vgpb0+n0YvYOX5bBKxjjjmg0tqVBGsiMSullWwDhrWPUEjpUPjVljPejIt4Efjap9eJczeBsU0iSQJKEdWjSxuFI1DTfTuu4NwTXZm8S4qKKWIWSVWIU76GQ6XQnkQDax8DW3xPh3jn2qilG6dPk/4L3JWuW/R3T8N19fvV0V/iMY4VmCGy89x++rf9i2IMmAZyLXlf7Aoqr8xwjJhnsLiwBJ9QPrvVoexM3yxT4u/32/CscFNsR4qUqSY/0UUUyJEZxFhe1w0iDqpqp0gKmzDcVddR2IyWBzdkF6zyYoz5m2LPLFyK8yfT2t2PdVWdv0UUs2/TYfbUXlKYjG4t8XHIkDhlRSdWnUVKKiixudKm5NWg3D8Olwq2LoyX8nUqfvpE4finwBmilw0kve1wtGpZdahlU327pB9R4b0nkwxhKKd6f39Ed74dxMp4czxqPa0kk63i33tnz6XfRIW+EIcUflBwzR91LyBwrBgpvYBlIvceVNPDLrNDNiOzWOURyRSaBpRrhGV9PIN3WB0251zZNlmLwWHlb5M8kuIUqoVSxjHVpAAbHcWH5pvU1wfkUsGBm1oRJLchPygAvd2HUknb0rHFB1W9078vA6HxTiMc1kyJx3lBQaq5clO6dtLpfh4Uz2IfxM+jf2uHqNzrECDCQ4kKDKA0KE7hNbzGRrX3OlbD1qfjwT/IGXQ+vVsuk6ra0J259Psrjzfh6XEZasagiVH1hW7pNmfu78iQ5Iv5VHwrGlxeHtI93so3a2+Zfg4PG5muHyKD31y5NXTj7Xo2Ia5RMmBaftQI5CmqLfUwEjIjHa3vBiN66MNPi8Pgop0kUwM7J2bIrANuTqDDdWs3X767ymNkwa4H5BLrBA7QhlXSrs6i5AXYsd9VrCtvGES4TL8PgSwabV2r2N9Pvk/1nsPHSa9vr1SWOdNuT22fd332/wBnnNNLUrVLzW4l+1OZRNliwRjR2SzJFe41zTEsnpdQvoBWviLiyafDZjhMXBDHiUdHZol03KTqjK25DWLizX5E86nvaXwpiI8Pl2MjiaQ4aNVmQAllswlW4A90EuCem1QMnC+KzI5pj4oJVV+9CjrpeQmaN2CjqQiHle5IHOuBJRUmo8unoPKTe768zozJQeFMMSOWI29e1xI+4mpOdmOQZYW56pB+qGcL9gFLWEOMxuAwuTxYOUPHOzvIwZUAJcrruvdA7R73+iLXJtVo8b8NyJgMHhsOjSiGynSrMdo9OohfE3PxrPJ8rH/hUlHjMbbpWQHtHHzOX/zS/sQ1hm+XmPMsZjpUukAhkiBNg82iBItWk30hrsRtfTbrUtx/keJlhwCxQu5jhAcBS2k6YxY25HY/VTlxLw4MRhJo1AEsiLzOxePSygnwutr+dZpO5VzpV9jbjpxfCYFF7rtP/SqyoMvy3EyYfFYxZERGDiQG+qRdSPIEGk7BmTqPvr3KPlkeBnnhlCwLIqSxkK2ouFW5V1IK95VIqVwMuKhwU2AbATmRywRhGxAVymsGw726XBBI+ArpzLB/IMnaCYgYjFSq/Z3BKqrId7eATfzcCldFLVvtF3zW5w6JU40PlBmRI4zIoV0jQIupZdDvZQL3sLXva5qIXMcThsLBYx9lKsukaRqB3RjqtqDbixB5Wpk4LyQzZP2bbNJ2jITy/wCZqQnyuoPoaj8Hw9icR8nw00DRxwFw7nbUrOGITxO1gRcb3queOSUouN24pKvG03deXier+D58C4Rwy6aU9UtVctDppPm9SS23VmjK0H8EYo23Ml/6Jgt+2ajse5OAwoPISyhfS0ZP9YtU3/uzj40kwaKrwySBu01ACwtuRe4/JuLE93a9dvFHC0vybCwQJrMZYsbqN2sSdyOZvWLxTcHs9opfW/5OpDjuHjnV5ItSyuadraPZ1u+jvanubc9mT5LilDd/5MpI32GiLy8/tpc4bb/hGIHlif2MPTvxFkurAz9nGTO8AWw3JICbDz7o+qkDLoswiwcuFGXuwfX84VcMokVVIC239wb3r0nDYl2LimvnT3aXm+Z5fFJzx1avUuqWyVdTLh8j+Bcbf6Z+u2Ht9tqOHl/4eof3WxLkA/REUI28tdasBkuZHCnBrhWVJJg7sx0nYKoBudlBUNcA3++ycj4Wihw0UDgOUBuehZzqcjyv9gFX43RLHOF/NK9t9kkXz5lBOmm3K/HavIrPOYGkjjijAtddXKwAB8ud7VZfs/yf5JgoofC5JPMkkkn6yak4cjgU3EYvUiBXMx4o41SEMmWWTme0UUVqZBRRRQAUUUUAFFFFABSvxguJkMOHwzmPtS5kkF7oiBeo33LAbbnbcC9NFFXhPTLV+dyGrVCRDwCdteOxRPXS5XfyuTXblXAuFhk7U9pM4OoNKwaxHWwABPmb8qaqK0fE5WmtXPw2/BXs4+AUUUVgXCiiigApY47xGJEMUWEOmWeZYg3IqpV3Zgelgu55gXtvamesCoNiRy5eXTaokrVAxAg9nMpX53MsST10swF/1mNb8N7MMKHDzSzTkdJGFjbkDYaiPK9PdFU7KHh+yNKNcUYUBVACgAAAWAA2AAHIVsoorQkKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD//2Q==' ,
                width: double.infinity,
                height: 350,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 32,) ,
            const Text(
              'Song',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4,),
            const Text(
              'hello',
              style: TextStyle(
                fontSize: 20,
              ),
            ),
            Slider(
                min : 0 ,
                max : duration.inSeconds.toDouble(),
                value: position.inSeconds.toDouble(),
                onChanged: (val) async {
                  final position = Duration(seconds: val.toInt()) ;
                  await audioPlayer.seek(position) ;
                  await audioPlayer.resume() ;
                } ,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(Duration(minutes: position.inSeconds).toString()) ,
                  Text(Duration(minutes: (duration - position).inSeconds).toString()) ,
                ],
              ),
            ),
            CircleAvatar(
              radius: 35,
              child: IconButton(
                icon: Icon(
                  isPlaying ? Icons.pause : Icons.play_arrow,
                ),
                iconSize: 50,
                onPressed: () async {
                  if(isPlaying){
                    await audioPlayer.pause() ;
                  }
                  else{
                    await audioPlayer.resume() ;
                    /*
                    String url = 'https://youtu.be/8-PRmp2h9ck';
                    await audioPlayer.play(url) ;
                     */
                  }
                },
              ),
            )
          ],
        ),
      )
    ) ;
  }
}
