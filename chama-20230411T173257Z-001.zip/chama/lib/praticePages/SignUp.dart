import 'package:flutter/material.dart';

class SignUp extends StatefulWidget {
  const SignUp({Key? key}) : super(key: key);

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {

  late String email;

  late String password;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 115 ,
          flexibleSpace: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween ,
                    children: <Widget>[
                      const Text('Practice Login Page',
                        style: TextStyle(
                          fontWeight: FontWeight.bold ,
                          color: Colors.white ,
                          fontSize: 20.0
                        ),
                      ) ,
                      Row(
                        //mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          IconButton(onPressed: (){}, icon: const Icon(Icons.search_rounded) , color: Colors.white,),
                          IconButton(onPressed: (){}, icon: const Icon(Icons.menu_outlined) , color: Colors.white,),
                        ],
                      )
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      TextButton(
                        onPressed: () {

                        },
                        child: Icon(Icons.group , color: Colors.white,) ,
                      ),
                      Row(
                        children: <Widget>[
                          TextButton(
                            onPressed: (){

                            } ,
                            child: const Text('CHATS',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold ,
                                  fontSize: 20.0 ,
                                  color: Colors.white
                              ),
                            ),
                          ),
                          TextButton(
                            onPressed: (){

                            } ,
                            child: const Text('STATUS',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold ,
                                  fontSize: 20.0 ,
                                  color: Colors.white
                              ),
                            ),
                          ),
                          TextButton(
                            onPressed: (){

                            } ,
                            child: const Text('CALLS',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold ,
                                  fontSize: 20.0 ,
                                  color: Colors.white
                              ),
                            ),
                          ),
                        ],
                      ) ,
                    ],
                  ),
                ],
              ),
            ),
          ),
          backgroundColor: Colors.black38,
        ),



      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20.0 , horizontal: 50.0),
          child: Form(
            child: Column(
              children: <Widget>[
                const SizedBox(height:20.0) ,
                TextFormField(
                  decoration: const InputDecoration(
                    hintText: 'Email',
                    fillColor: Colors.white,
                    filled: true ,
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(10.0)) ,
                      borderSide: BorderSide(color: Colors.blue),
                    ),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(25.0)) ,
                      borderSide: BorderSide(color: Colors.white)
                    )
                  ),
                  onChanged: (val){
                    setState( () => email = val);
                  }
                ) ,
                const SizedBox(height: 20.0),
                TextFormField(
                  decoration: const InputDecoration(
                      hintText: 'Password',
                      fillColor: Colors.white,
                      filled: true ,
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(10.0)) ,
                        borderSide: BorderSide(color: Colors.blue),
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(25.0)) ,
                          borderSide: BorderSide(color: Colors.white)
                      )
                  ),
                  obscureText: true,
                  onChanged: (val){
                    setState(() => password = val);
                  },
                ) ,
                const SizedBox(height: 20.0),
                ElevatedButton(
                    onPressed: (){
                      print(email) ;
                      print(password) ;
                    },
                    child: const Text('Sign Up'),
                ),
              ],
            ),
          ),
        ),
      ) ,
      backgroundColor: Colors.blueGrey,
    );
  }
}
