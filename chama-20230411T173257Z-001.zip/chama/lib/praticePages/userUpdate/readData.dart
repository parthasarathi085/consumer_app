import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
//import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'Users.dart';

class readData extends StatefulWidget {
  const readData({Key? key}) : super(key: key);

  @override
  State<readData> createState() => _readDataState();
}

class _readDataState extends State<readData> {

  final controller = TextEditingController() ;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title : const Text('User Update') ,
        centerTitle: true,
        backgroundColor: Colors.black26,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: StreamBuilder<List<User>>(
          stream: readUsers(),
            builder: (context , snapshot){
            if(snapshot.hasError){
              return Text('Something went wrong ${snapshot.error}') ;
            }
            else if(snapshot.hasData){
              final users = snapshot.data! ;

              return ListView(
                children: users.map(buildUser).toList(),
              ) ;
            }
            else{
              return const Center(child: CircularProgressIndicator(),) ;
            }
            },
        ),
      ) ,
      backgroundColor: Colors.grey,
    );
  }

  Widget buildUser(User user) => Card(
    margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
    child: ListTile(
      leading: CircleAvatar(child: Text(user.age.toString()),backgroundColor: Colors.black38,foregroundColor: Colors.white,),
      title: Text(user.name),
      subtitle: Text(user.name),
    ),
  ) ;

  Stream<List<User>> readUsers() => FirebaseFirestore.instance
      .collection('User')
      .snapshots()
      .map((snapshot) => snapshot.docs.map((doc) => User.fromJson(doc.data())).toList()) ;

  Future read({required String name , required String age}) async{
    //final docUser = FirebaseFirestore.instance.collection('User').doc('name') ;
    final docUser = FirebaseFirestore.instance.collection('User').doc() ;
  }
}