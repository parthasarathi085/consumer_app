import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class createUser extends StatefulWidget {
  const createUser({Key? key}) : super(key: key);

  @override
  State<createUser> createState() => _createUserState();
}

class _createUserState extends State<createUser> {

  final NameController = TextEditingController() ;
  final AgeController = TextEditingController() ;

  late String name ;
  late int age = int.parse(AgeController.text) ;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title : const Text('User Update') ,
        centerTitle: true,
        backgroundColor: Colors.black26,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20,horizontal: 50),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const SizedBox(height : 20) ,
              TextFormField(
                controller: NameController,
                decoration: const InputDecoration(
                  icon: Icon(Icons.account_circle_outlined , color: Colors.black,),
                  hintText: 'Name',
                  hintStyle: TextStyle(
                    color: Colors.white ,
                    fontWeight: FontWeight.bold ,
                  ),
                ),
                onChanged: (val) => name = val,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: (name) => name != null && name.length < 2 ? 'Enter atleast thre characters !': null ,
              ),
              const SizedBox(height : 20) ,
              TextFormField(
                controller: AgeController,
                decoration: const InputDecoration(
                  icon: Icon(Icons.onetwothree , color: Colors.black,),
                  hintText: 'Age',
                  hintStyle: TextStyle(
                    color: Colors.white ,
                    fontWeight: FontWeight.bold ,
                  ),
                ),
                onChanged: (val) => age = int.parse(val),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: (age) => age != null && int.parse(age) < 10 ? 'You are not eligible': null ,
              ),
              const SizedBox(height : 20) ,
              ElevatedButton.icon(
                onPressed: (){
                  update(name : name , age : age) ;
                },
                icon: const Icon(Icons.update_outlined,color: Colors.black,),
                label: const Text('Update'),
              ),
            ],
          ),
        ),
      ),
      backgroundColor: Colors.grey,
    );
  }

  Future update({required String name , required int age}) async{
    //final docUser = FirebaseFirestore.instance.collection('User').doc('name') ;
    final docUser = FirebaseFirestore.instance.collection('User').doc(name) ;

    final user = createId(id : name, name:name, age:age) ;

    /*
    final json = {
      'name' :name ,
      'age' : 26 ,
    } ;
    */

    final json = user.toJson() ;

    await docUser.set(json) ;


  }
}

class createId {
  String id = '' ;
  final String name ;
  final int age ;
  createId({required this.id ,required this.name ,required this.age});

  Map<String , dynamic> toJson() => {
    'id' : id ,
    'name' : name ,
    'age' : age ,
  };
}