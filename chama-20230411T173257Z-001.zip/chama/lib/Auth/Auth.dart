import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:chama/Sign Up/SignUp.dart';
import 'package:chama/Sign In/SignIn.dart';
import 'package:flutter/gestures.dart';
import 'package:chama/main.dart';

class Auth extends StatefulWidget {
  const Auth({Key? key}) : super(key: key);

  @override
  State<Auth> createState() => _AuthState();
}

class _AuthState extends State<Auth> {

  bool isLogin = true ;

  @override
  Widget build(BuildContext context) => isLogin
      ? SignIn(onClickedSignUp: toggle)
      : SignUp(onClickedSignIn: toggle) ;

  void toggle() => setState(() => isLogin = !isLogin) ;
}
