import 'dart:async';
import 'package:chama/Utils/Utils.dart';
import 'package:flutter/material.dart';
import 'package:chama/Home/Home.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class VerifyEmail extends StatefulWidget {
  const VerifyEmail({Key? key}) : super(key: key);

  @override
  State<VerifyEmail> createState() => _VerifyEmailState();
}

class _VerifyEmailState extends State<VerifyEmail> {

  bool isEmailVerified = false ;
  bool canResendEmail = false ;
  Timer? timer ;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    isEmailVerified = FirebaseAuth.instance.currentUser!.emailVerified ;

    if(!isEmailVerified) {
      sendVerificationEmail();

      timer = Timer.periodic(
          const Duration(seconds: 3), (_) => checkEmailVerified(),
      );
    }
  }

  Future checkEmailVerified() async{

    await FirebaseAuth.instance.currentUser!.reload() ;

    setState(() {
      isEmailVerified = FirebaseAuth.instance.currentUser!.emailVerified ;
    });

    if(isEmailVerified) timer?.cancel() ;

  }

  @override
  void dispose() {
    timer?.cancel() ;
    // TODO: implement dispose
    super.dispose();
  }

  Future sendVerificationEmail() async{
    try{
      final user = FirebaseAuth.instance.currentUser! ;
      await user.sendEmailVerification() ;

      setState(() => canResendEmail = false);
      await Future.delayed(const Duration(seconds: 5)) ;
      setState(() => canResendEmail = true);
    }
    catch(e){
      Utils.showSnackBar(e.toString()) ;
    }
  }

  @override
  Widget build(BuildContext context) => isEmailVerified
      ? const Home()
      : Scaffold(
    appBar: AppBar(
      title: const Text('Verify Email'),
      backgroundColor: Colors.black26,
    ),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20 ,horizontal: 50),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text('Email verification Sent to your Email',
              style: TextStyle(
                fontWeight: FontWeight.bold ,
                fontSize: 20,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20,) ,
            ElevatedButton.icon(
                onPressed: canResendEmail ? sendVerificationEmail : null,
                icon: const Icon(Icons.mail , color: Colors.black,),
                label: const Text('Resent Email') ,
            ),
            const SizedBox(height: 10,) ,
            ElevatedButton.icon(
              onPressed: () => FirebaseAuth.instance.signOut() ,
              icon: const Icon(Icons.cancel , color: Colors.white,),
              label: const Text('Cancel',
                style: TextStyle(
                  color: Colors.white ,
                ),
              ) ,
            ),
          ],
        ),
      ),
    ),
    backgroundColor: Colors.grey ,
  ) ;
}
