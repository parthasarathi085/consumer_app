import 'package:chama/Home/Home.dart';
import 'package:chama/Player/Player.dart';
import 'package:chama/praticePages/userUpdate/UserUpdate.dart';
import 'package:chama/praticePages/userUpdate/createUser.dart';
import 'package:chama/praticePages/userUpdate/readData.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:chama/Auth/Auth.dart';
import 'package:chama/Utils/Utils.dart';
import 'package:chama/VerifyEmail/VerifyEmail.dart';

Future<void> main() async {

  WidgetsFlutterBinding.ensureInitialized() ;
  await Firebase.initializeApp() ;

  return runApp(MaterialApp(
    
    debugShowCheckedModeBanner: false ,
    
    scaffoldMessengerKey: Utils.messegerKey ,

    home : const Sign() ,

    routes: {
      '/home' : (context) => const Home() ,
      '/readData' : (context) => const readData() ,
      '/createUser' : (context) => const createUser() ,
      '/Player' : (context) => const Player() ,
    },

  )) ;

}


class Sign extends StatelessWidget {
  const Sign({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: StreamBuilder<User?>(
            stream : FirebaseAuth.instance.authStateChanges(),
            builder: (context , snapshot){

              if(snapshot.connectionState == ConnectionState.waiting){
                return const Center(child: CircularProgressIndicator(),) ;
              }

              else if(snapshot.hasError){
                return const Center(child: Text('Access Denied'),) ;
              }
              else if(snapshot.hasData){
                return const VerifyEmail() ;
              }
              else{
                return const Auth() ;
              }
            }
        )
    );
  }
}
